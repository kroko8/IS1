package domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


@Entity
public class Bet {
	@GeneratedValue
	@Id
	@XmlJavaTypeAdapter(IntegerAdapter.class)
	private Integer betNumber;
	private Forecast forecast;
	private User user;
	private float amount;
	private String estadoApuesta; // Awaiting Win Lose Canceled
	
	
	public Bet() {
		super();
	}

	public Bet(Integer n, Forecast forecast, User user, float amount) {
		super();
		this.betNumber = n;
		this.forecast = forecast;
		this.user = user;
		this.amount = amount;
		this.estadoApuesta = "Awaiting";
	}

	public Bet(Forecast forecast, User user, float amount) {
		super();
		this.forecast = forecast;
		this.user = user;
		this.amount = amount;
		this.estadoApuesta = "Awaiting";

	}

	public Forecast getForecast() {
		return forecast;
	}

	public void setForecast(Forecast forecast) {
		this.forecast = forecast;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	public  String getEstadoApuesta() {
		return estadoApuesta;
	}

	public void setEstadoApuesta(String estadoApuesta) {
		this.estadoApuesta = estadoApuesta;
	}


	@Override
	public String toString() {
		return "Bet [forecast: " + forecast + ", user: " + user + ", amount: " + amount + "forecast: "
				+ forecast.getForecast() + "question: " + forecast.getQuestion().getQuestion() + "event: "
				+ forecast.getQuestion().getEvent().getDescription() + "]";
	}

	public String toString2() {

		

		

		return forecast.getQuestion().getEvent().getEventDate().toString().substring(0, 11) + "             "
				+ forecast.getQuestion().getEvent().getDescription() + "                             "
				+ forecast.getQuestion().getQuestion() + "                                                  "
				+ this.forecast.getForecast() + "                                           "
				+ estadoApuesta + "                                "
				+ forecast.getQuestion().getResult() + "                    " + this.getAmount()
				+ "                         " + forecast.getFee();



	}

	public String toString3() {

		return forecast.getQuestion().getEvent().getEventDate().toString().substring(0, 11)
				+ "                                   " + forecast.getQuestion().getEvent().getDescription()
				+ "                                        " + forecast.getQuestion().getQuestion()
				+ "                                    " + this.forecast.getForecast()
				+ "                                                         " + this.getAmount()
				+ "                                                             " + forecast.getFee();
	}
	
	public boolean equals(Bet b) {
		
		Forecast forecast1=forecast;
		Forecast forecast2=b.getForecast();
		User user1=user;
		User user2=b.getUser();
		float amount1=amount;
		float amount2=b.getAmount();
	
		if (forecast1==forecast2 && user1==user2 && amount1==amount2) {
			return true;
		}
		return false;
	}
}
